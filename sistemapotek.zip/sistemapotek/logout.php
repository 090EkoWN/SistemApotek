<?php
// ============================================================
// logout.php — Hapus Session dan Redirect ke Login
// ============================================================
session_start();
session_unset();
session_destroy();
header('Location: index.php?msg=logout');
exit();
?>